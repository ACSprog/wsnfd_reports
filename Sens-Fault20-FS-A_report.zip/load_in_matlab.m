% Load wsnfd results in MATLAB.  Run from the folder that holds this file.
% Option A: native file (recommended)
S = load('results.mat');                 % one struct per table: S.raw_runs, S.summary, ...
f1  = S.raw_runs.post_change_f1;         % numeric columns are double vectors
mdl = string(S.raw_runs.model);          % text columns are cell arrays
scn = string(S.raw_runs.scenario);
% Example: mean post-change F1 by model for scenario S2
for m = unique(mdl)'
    fprintf('%s  %.3f\n', m, mean(f1(mdl==m & scn=="S2"), 'omitnan'));
end
% Option B: any table as CSV
T = readtable(fullfile('tables','summary.csv'));
% Boxplot over seeds
boxplot(f1(scn=="S2"), mdl(scn=="S2")); ylabel('post-change F1');
% Labelled dataset (if you exported dataset_*.mat):  D = load('dataset_S2_seed0.mat').dataset;
