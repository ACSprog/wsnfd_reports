# Load wsnfd results in Python / Jupyter.
import pandas as pd
runs = pd.read_csv("tables/raw_runs.csv")
print(runs.groupby(["scenario", "model"])["post_change_f1"].agg(["mean", "std", "count"]))
# xls = pd.read_excel("results.xlsx", sheet_name=None)   # every sheet as a DataFrame
# D = pd.read_parquet("dataset_S2_seed0.parquet")        # labelled dataset
